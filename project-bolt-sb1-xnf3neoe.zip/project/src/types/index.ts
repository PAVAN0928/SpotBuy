export interface User {
  id: string;
  email: string;
  name: string;
  type: 'customer' | 'shop_owner';
  avatar?: string;
  location?: {
    lat: number;
    lng: number;
    address: string;
  };
}

export interface Shop {
  id: string;
  name: string;
  description: string;
  ownerId: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  image: string;
  rating: number;
  verified: boolean;
  categories: string[];
  openHours: {
    open: string;
    close: string;
  };
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  shopId: string;
  shopName: string;
  quantity: number;
  discount?: number;
  rating: number;
  tags: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  type: 'buy_now' | 'reserve' | 'try_before_buy';
}

export interface Order {
  id: string;
  customerId: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'confirmed' | 'preparing' | 'ready' | 'completed' | 'cancelled';
  paymentMethod: 'online' | 'store';
  createdAt: string;
  estimatedTime?: string;
}

export interface Currency {
  code: string;
  symbol: string;
  name: string;
  rate: number; // Exchange rate relative to USD
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, type: 'customer' | 'shop_owner') => Promise<void>;
  register: (email: string, password: string, name: string, type: 'customer' | 'shop_owner') => Promise<void>;
  logout: () => void;
  loading: boolean;
}

export interface AppContextType {
  shops: Shop[];
  products: Product[];
  cart: CartItem[];
  orders: Order[];
  currencies: Currency[];
  selectedCurrency: Currency;
  setSelectedCurrency: (currency: Currency) => void;
  formatPrice: (price: number) => string;
  addToCart: (product: Product, quantity: number, type: CartItem['type']) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  createOrder: (paymentMethod: 'online' | 'store') => Promise<void>;
  searchProducts: (query: string) => Product[];
  filterProducts: (category?: string, shopId?: string) => Product[];
}