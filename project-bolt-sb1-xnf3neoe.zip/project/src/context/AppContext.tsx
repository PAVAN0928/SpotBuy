import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Shop, Product, CartItem, Order, AppContextType, Currency } from '../types';

const AppContext = createContext<AppContextType | undefined>(undefined);

// Currency data
const currencies: Currency[] = [
  { code: 'USD', symbol: '$', name: 'US Dollar', rate: 1 },
  { code: 'EUR', symbol: '€', name: 'Euro', rate: 0.85 },
  { code: 'GBP', symbol: '£', name: 'British Pound', rate: 0.73 },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen', rate: 110 },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar', rate: 1.25 },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', rate: 1.35 },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee', rate: 74 },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan', rate: 6.45 }
];

// Mock data for demo
const mockShops: Shop[] = [
  {
    id: '1',
    name: 'TechHub Electronics',
    description: 'Premium electronics and gadgets store',
    ownerId: '2',
    location: { lat: 40.7589, lng: -73.9851, address: '123 Tech Street, Manhattan, NY' },
    image: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?w=800',
    rating: 4.8,
    verified: true,
    categories: ['Electronics', 'Gadgets'],
    openHours: { open: '09:00', close: '21:00' }
  },
  {
    id: '2',
    name: 'Urban Fashion',
    description: 'Modern streetwear and fashion essentials',
    ownerId: '2',
    location: { lat: 40.7505, lng: -73.9934, address: '456 Fashion Ave, NYC' },
    image: 'https://images.pexels.com/photos/1884581/pexels-photo-1884581.jpeg?w=800',
    rating: 4.6,
    verified: true,
    categories: ['Fashion', 'Clothing'],
    openHours: { open: '10:00', close: '22:00' }
  },
  {
    id: '3',
    name: 'Healthy Living',
    description: 'Organic foods and wellness products',
    ownerId: '2',
    location: { lat: 40.7614, lng: -73.9776, address: '789 Wellness Blvd, NYC' },
    image: 'https://images.pexels.com/photos/264636/pexels-photo-264636.jpeg?w=800',
    rating: 4.9,
    verified: true,
    categories: ['Health', 'Organic'],
    openHours: { open: '08:00', close: '20:00' }
  }
];

const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Wireless Pro Headphones',
    description: 'Premium noise-cancelling wireless headphones with spatial audio',
    price: 299.99,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?w=400',
    category: 'Electronics',
    shopId: '1',
    shopName: 'TechHub Electronics',
    quantity: 15,
    discount: 10,
    rating: 4.7,
    tags: ['wireless', 'audio', 'premium']
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    description: 'Advanced fitness tracking with heart rate monitoring',
    price: 249.99,
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?w=400',
    category: 'Electronics',
    shopId: '1',
    shopName: 'TechHub Electronics',
    quantity: 8,
    rating: 4.5,
    tags: ['fitness', 'smart', 'health']
  },
  {
    id: '3',
    name: 'Designer Sneakers',
    description: 'Limited edition streetwear sneakers',
    price: 189.99,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?w=400',
    category: 'Fashion',
    shopId: '2',
    shopName: 'Urban Fashion',
    quantity: 12,
    discount: 15,
    rating: 4.8,
    tags: ['sneakers', 'limited', 'streetwear']
  },
  {
    id: '4',
    name: 'Organic Protein Powder',
    description: 'Plant-based protein powder for healthy living',
    price: 49.99,
    image: 'https://images.pexels.com/photos/4162492/pexels-photo-4162492.jpeg?w=400',
    category: 'Health',
    shopId: '3',
    shopName: 'Healthy Living',
    quantity: 25,
    rating: 4.6,
    tags: ['organic', 'protein', 'health']
  },
  {
    id: '5',
    name: 'Wireless Charging Pad',
    description: 'Fast wireless charging for all devices',
    price: 79.99,
    image: 'https://images.pexels.com/photos/4068314/pexels-photo-4068314.jpeg?w=400',
    category: 'Electronics',
    shopId: '1',
    shopName: 'TechHub Electronics',
    quantity: 20,
    rating: 4.4,
    tags: ['wireless', 'charging', 'tech']
  },
  {
    id: '6',
    name: 'Eco-Friendly Water Bottle',
    description: 'Sustainable stainless steel water bottle',
    price: 24.99,
    image: 'https://images.pexels.com/photos/1000084/pexels-photo-1000084.jpeg?w=400',
    category: 'Health',
    shopId: '3',
    shopName: 'Healthy Living',
    quantity: 30,
    rating: 4.7,
    tags: ['eco', 'sustainable', 'water']
  }
];

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [shops] = useState<Shop[]>(mockShops);
  const [products] = useState<Product[]>(mockProducts);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>(currencies[0]); // Default to USD

  const formatPrice = (price: number) => {
    const convertedPrice = price * selectedCurrency.rate;
    return `${selectedCurrency.symbol}${convertedPrice.toFixed(2)}`;
  };

  const addToCart = (product: Product, quantity: number, type: CartItem['type']) => {
    const existingItem = cart.find(item => item.product.id === product.id && item.type === type);
    
    if (existingItem) {
      setCart(cart.map(item =>
        item.product.id === product.id && item.type === type
          ? { ...item, quantity: item.quantity + quantity }
          : item
      ));
    } else {
      setCart([...cart, { product, quantity, type }]);
    }
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    
    setCart(cart.map(item =>
      item.product.id === productId
        ? { ...item, quantity }
        : item
    ));
  };

  const clearCart = () => {
    setCart([]);
  };

  const createOrder = async (paymentMethod: 'online' | 'store') => {
    const total = cart.reduce((sum, item) => {
      const price = item.product.discount 
        ? item.product.price * (1 - item.product.discount / 100)
        : item.product.price;
      return sum + (price * item.quantity);
    }, 0);

    const newOrder: Order = {
      id: Date.now().toString(),
      customerId: '1', // Mock customer ID
      items: [...cart],
      total,
      status: 'pending',
      paymentMethod,
      createdAt: new Date().toISOString(),
      estimatedTime: paymentMethod === 'store' ? '30 mins' : '2-3 days'
    };

    setOrders([newOrder, ...orders]);
    clearCart();
  };

  const searchProducts = (query: string) => {
    const lowercaseQuery = query.toLowerCase();
    return products.filter(product =>
      product.name.toLowerCase().includes(lowercaseQuery) ||
      product.description.toLowerCase().includes(lowercaseQuery) ||
      product.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery))
    );
  };

  const filterProducts = (category?: string, shopId?: string) => {
    return products.filter(product => {
      if (category && product.category !== category) return false;
      if (shopId && product.shopId !== shopId) return false;
      return true;
    });
  };

  return (
    <AppContext.Provider value={{
      shops,
      products,
      cart,
      orders,
      currencies,
      selectedCurrency,
      setSelectedCurrency,
      formatPrice,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      clearCart,
      createOrder,
      searchProducts,
      filterProducts
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};