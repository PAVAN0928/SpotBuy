import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { AppProvider } from './context/AppContext';
import Navigation from './components/Navigation';
import AuthModal from './components/AuthModal';
import ProductGrid from './components/ProductGrid';
import ShopOwnerDashboard from './components/ShopOwnerDashboard';
import CartModal from './components/CartModal';
import { useAuth } from './context/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';

const AppContent: React.FC = () => {
  const { user } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showCartModal, setShowCartModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Animated background effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <Navigation 
        onAuthClick={() => setShowAuthModal(true)}
        onCartClick={() => setShowCartModal(true)}
        onSearchChange={setSearchQuery}
      />

      <main className="relative z-10 pt-20">
        <AnimatePresence mode="wait">
          {user?.type === 'shop_owner' ? (
            <motion.div
              key="shop-dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              <ShopOwnerDashboard />
            </motion.div>
          ) : (
            <motion.div
              key="customer-view"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              <ProductGrid searchQuery={searchQuery} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Modals */}
      <AnimatePresence>
        {showAuthModal && (
          <AuthModal onClose={() => setShowAuthModal(false)} />
        )}
        {showCartModal && (
          <CartModal onClose={() => setShowCartModal(false)} />
        )}
      </AnimatePresence>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </AuthProvider>
  );
};

export default App;