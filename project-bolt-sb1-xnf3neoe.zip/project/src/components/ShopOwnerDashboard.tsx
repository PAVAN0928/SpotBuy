import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Store, 
  Package, 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  TrendingUp,
  Users,
  ShoppingBag,
  DollarSign,
  Star,
  MapPin
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Product } from '../types';

const ShopOwnerDashboard: React.FC = () => {
  const { products, shops, orders, formatPrice } = useApp();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'shop'>('overview');
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Get user's shop and products
  const userShop = shops.find(shop => shop.ownerId === user?.id);
  const userProducts = products.filter(product => product.shopId === userShop?.id);
  const userOrders = orders.filter(order => 
    order.items.some(item => item.product.shopId === userShop?.id)
  );

  const stats = {
    totalProducts: userProducts.length,
    totalOrders: userOrders.length,
    totalRevenue: userOrders.reduce((sum, order) => sum + order.total, 0),
    avgRating: userShop?.rating || 0
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: TrendingUp },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'orders', label: 'Orders', icon: ShoppingBag },
    { id: 'shop', label: 'Shop Settings', icon: Store }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center space-x-4 mb-4">
          <div className="p-3 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-xl">
            <Store className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Shop Dashboard</h1>
            <p className="text-gray-400">
              Welcome back, {user?.name}! Manage your {userShop?.name || 'shop'}.
            </p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { label: 'Products', value: stats.totalProducts, icon: Package, color: 'from-blue-500 to-cyan-500', change: '+12%' },
            { label: 'Orders', value: stats.totalOrders, icon: ShoppingBag, color: 'from-green-500 to-emerald-500', change: '+8%' },
            { label: 'Revenue', value: formatPrice(stats.totalRevenue), icon: DollarSign, color: 'from-purple-500 to-pink-500', change: '+15%' },
            { label: 'Rating', value: stats.avgRating.toFixed(1), icon: Star, color: 'from-yellow-500 to-orange-500', change: '+0.2' }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-800"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 bg-gradient-to-r ${stat.color} rounded-lg`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <span className="text-green-400 text-sm font-medium">{stat.change}</span>
              </div>
              <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-gray-400 text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Tab Navigation */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="flex space-x-1 bg-gray-900/50 backdrop-blur-sm rounded-2xl p-2 mb-8 border border-gray-800"
      >
        {tabs.map((tab) => (
          <motion.button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white'
                : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <tab.icon className="w-5 h-5" />
            <span>{tab.label}</span>
          </motion.button>
        ))}
      </motion.div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {activeTab === 'overview' && (
            <div className="space-y-8">
              {/* Recent Orders */}
              <div className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-800">
                <h3 className="text-xl font-bold text-white mb-6">Recent Orders</h3>
                <div className="space-y-4">
                  {userOrders.slice(0, 5).map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-xl">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full flex items-center justify-center">
                          <ShoppingBag className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="text-white font-medium">Order #{order.id.slice(-6)}</div>
                          <div className="text-gray-400 text-sm">{order.items.length} items</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-cyan-400 font-bold">{formatPrice(order.total)}</div>
                        <div className={`text-xs px-2 py-1 rounded-full ${
                          order.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                          order.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-blue-500/20 text-blue-400'
                        }`}>
                          {order.status}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Top Products */}
              <div className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-800">
                <h3 className="text-xl font-bold text-white mb-6">Top Products</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {userProducts.slice(0, 6).map((product) => (
                    <div key={product.id} className="flex items-center space-x-3 p-3 bg-gray-800/50 rounded-xl">
                      <img src={product.image} alt={product.name} className="w-12 h-12 object-cover rounded-lg" />
                      <div className="flex-1 min-w-0">
                        <div className="text-white font-medium truncate">{product.name}</div>
                        <div className="text-cyan-400 font-bold">{formatPrice(product.price)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="space-y-6">
              {/* Products Header */}
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-white">Products Management</h3>
                <motion.button
                  onClick={() => setShowAddProduct(true)}
                  className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-white rounded-lg font-medium hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Plus className="w-5 h-5" />
                  <span>Add Product</span>
                </motion.button>
              </div>

              {/* Products Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {userProducts.map((product) => (
                  <motion.div
                    key={product.id}
                    className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-sm rounded-2xl overflow-hidden border border-gray-800"
                    whileHover={{ scale: 1.02 }}
                  >
                    <img src={product.image} alt={product.name} className="w-full h-48 object-cover" />
                    <div className="p-4">
                      <h4 className="text-lg font-semibold text-white mb-2">{product.name}</h4>
                      <p className="text-gray-400 text-sm mb-3 line-clamp-2">{product.description}</p>
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-cyan-400 font-bold text-xl">{formatPrice(product.price)}</span>
                        <span className="text-gray-400">Stock: {product.quantity}</span>
                      </div>
                      <div className="flex space-x-2">
                        <motion.button
                          onClick={() => setEditingProduct(product)}
                          className="flex-1 flex items-center justify-center space-x-1 px-3 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-colors"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Edit className="w-4 h-4" />
                          <span>Edit</span>
                        </motion.button>
                        <motion.button
                          className="flex-1 flex items-center justify-center space-x-1 px-3 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>Delete</span>
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white">Orders Management</h3>
              <div className="space-y-4">
                {userOrders.map((order) => (
                  <motion.div
                    key={order.id}
                    className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-800"
                    whileHover={{ scale: 1.01 }}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full flex items-center justify-center">
                          <ShoppingBag className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold text-white">Order #{order.id.slice(-8)}</h4>
                          <p className="text-gray-400">{new Date(order.createdAt).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-cyan-400">{formatPrice(order.total)}</div>
                        <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                          order.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                          order.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-blue-500/20 text-blue-400'
                        }`}>
                          {order.status}
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {order.items.map((item) => (
                        <div key={`${item.product.id}-${order.id}`} className="flex items-center space-x-3 p-3 bg-gray-800/50 rounded-xl">
                          <img src={item.product.image} alt={item.product.name} className="w-12 h-12 object-cover rounded-lg" />
                          <div className="flex-1 min-w-0">
                            <div className="text-white font-medium truncate">{item.product.name}</div>
                            <div className="text-gray-400 text-sm">Qty: {item.quantity}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'shop' && userShop && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white">Shop Settings</h3>
              <div className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-800">
                <div className="flex items-start space-x-6">
                  <img src={userShop.image} alt={userShop.name} className="w-24 h-24 object-cover rounded-xl" />
                  <div className="flex-1">
                    <h4 className="text-2xl font-bold text-white mb-2">{userShop.name}</h4>
                    <p className="text-gray-400 mb-4">{userShop.description}</p>
                    <div className="flex items-center space-x-4 text-sm">
                      <div className="flex items-center space-x-1 text-yellow-400">
                        <Star className="w-4 h-4 fill-current" />
                        <span>{userShop.rating}</span>
                      </div>
                      <div className="flex items-center space-x-1 text-gray-400">
                        <MapPin className="w-4 h-4" />
                        <span>{userShop.location.address}</span>
                      </div>
                      <div className="flex items-center space-x-1 text-green-400">
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                        <span>Verified</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default ShopOwnerDashboard;