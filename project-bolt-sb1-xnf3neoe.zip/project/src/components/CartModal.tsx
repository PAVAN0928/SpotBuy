import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus, Trash2, ShoppingBag, CreditCard, Store } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';

interface CartModalProps {
  onClose: () => void;
}

const CartModal: React.FC<CartModalProps> = ({ onClose }) => {
  const { cart, updateCartQuantity, removeFromCart, createOrder, clearCart, formatPrice } = useApp();
  const { user } = useAuth();

  const total = cart.reduce((sum, item) => {
    const price = item.product.discount 
      ? item.product.price * (1 - item.product.discount / 100)
      : item.product.price;
    return sum + (price * item.quantity);
  }, 0);

  const handleCheckout = async (paymentMethod: 'online' | 'store') => {
    try {
      await createOrder(paymentMethod);
      onClose();
    } catch (error) {
      console.error('Checkout failed:', error);
    }
  };

  const getActionColor = (type: string) => {
    switch (type) {
      case 'buy_now':
        return 'from-green-500 to-emerald-500';
      case 'reserve':
        return 'from-blue-500 to-purple-500';
      case 'try_before_buy':
        return 'from-purple-500 to-pink-500';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const getActionLabel = (type: string) => {
    switch (type) {
      case 'buy_now':
        return 'Buy Now';
      case 'reserve':
        return 'Reserved';
      case 'try_before_buy':
        return 'Try First';
      default:
        return type;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: "spring", duration: 0.5 }}
        className="w-full max-w-2xl max-h-[90vh] bg-gradient-to-br from-gray-900 to-black rounded-2xl border border-gray-800 overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-800">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-lg">
              <ShoppingBag className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Shopping Cart</h2>
              <p className="text-sm text-gray-400">{cart.length} items</p>
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center p-6">
              <div className="w-16 h-16 mb-4 bg-gradient-to-br from-gray-800 to-gray-700 rounded-full flex items-center justify-center">
                <ShoppingBag className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Your cart is empty</h3>
              <p className="text-gray-400 mb-4">Add some products to get started</p>
              <motion.button
                onClick={onClose}
                className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-white rounded-lg font-medium hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Continue Shopping
              </motion.button>
            </div>
          ) : (
            <div className="p-6 space-y-4">
              <AnimatePresence>
                {cart.map((item) => {
                  const discountedPrice = item.product.discount 
                    ? item.product.price * (1 - item.product.discount / 100)
                    : item.product.price;

                  return (
                    <motion.div
                      key={`${item.product.id}-${item.type}`}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -100 }}
                      className="flex items-center space-x-4 p-4 bg-gray-800/50 rounded-xl border border-gray-700"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-white truncate">{item.product.name}</h4>
                        <p className="text-sm text-gray-400">{item.product.shopName}</p>
                        <div className={`inline-block px-2 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${getActionColor(item.type)} text-white mt-1`}>
                          {getActionLabel(item.type)}
                        </div>
                      </div>

                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-2 bg-gray-700 rounded-lg">
                          <motion.button
                            onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                            className="p-2 text-gray-300 hover:text-white transition-colors"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                          >
                            <Minus className="w-4 h-4" />
                          </motion.button>
                          <span className="text-white font-medium w-8 text-center">{item.quantity}</span>
                          <motion.button
                            onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                            className="p-2 text-gray-300 hover:text-white transition-colors"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                          >
                            <Plus className="w-4 h-4" />
                          </motion.button>
                        </div>

                        <div className="text-right">
                          <div className="text-lg font-bold text-cyan-400">
                            {formatPrice(discountedPrice * item.quantity)}
                          </div>
                          {item.product.discount && (
                            <div className="text-sm text-gray-500 line-through">
                              {formatPrice(item.product.price * item.quantity)}
                            </div>
                          )}
                        </div>

                        <motion.button
                          onClick={() => removeFromCart(item.product.id)}
                          className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </motion.button>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>

        {/* Footer */}
        {cart.length > 0 && (
          <div className="p-6 border-t border-gray-800 space-y-4">
            {/* Total */}
            <div className="flex items-center justify-between text-xl font-bold">
              <span className="text-white">Total:</span>
              <span className="text-cyan-400">{formatPrice(total)}</span>
            </div>

            {/* Action Buttons */}
            {user ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <motion.button
                  onClick={() => handleCheckout('online')}
                  className="flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg font-medium hover:shadow-lg hover:shadow-green-500/25 transition-all"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <CreditCard className="w-5 h-5" />
                  <span>Pay Online</span>
                </motion.button>
                
                <motion.button
                  onClick={() => handleCheckout('store')}
                  className="flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg font-medium hover:shadow-lg hover:shadow-blue-500/25 transition-all"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Store className="w-5 h-5" />
                  <span>Pay at Store</span>
                </motion.button>
              </div>
            ) : (
              <motion.button
                onClick={onClose}
                className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-white rounded-lg font-medium hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Sign In to Checkout
              </motion.button>
            )}

            {cart.length > 0 && (
              <motion.button
                onClick={clearCart}
                className="w-full px-4 py-2 text-gray-400 hover:text-red-400 transition-colors text-sm"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Clear Cart
              </motion.button>
            )}
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};

export default CartModal;